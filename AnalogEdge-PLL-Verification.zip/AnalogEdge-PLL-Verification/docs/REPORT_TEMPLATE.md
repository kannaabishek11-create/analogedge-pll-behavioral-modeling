# AnalogEdge PLL Project Report

## 1. Aim
To build and verify a behavioral model of a Phase-Locked Loop using Python.

## 2. Objectives
- Model PFD, charge pump, loop filter, and VCO.
- Observe frequency acquisition and phase-error settling.
- Estimate lock time.
- Study the effect of phase-measurement noise on equivalent timing variation.

## 3. Software requirements
- Python 3.10+
- NumPy
- Matplotlib
- GitHub for source-code version control

## 4. Block diagram
Reference phase → PFD → Charge Pump → Loop Filter → VCO → Feedback phase

## 5. Method
Explain how each Python module represents one PLL block. Record the parameters used.

## 6. Results
Insert `frequency_lock.png`, `phase_error.png`, and `jitter_sensitivity.png` from the results folder.

## 7. Discussion
Explain when the output approaches the reference frequency, how phase error changes, and how added measurement noise affects equivalent timing variation.

## 8. Limitations
This is a behavioral simulation. It is not a transistor-level PLL design or measured hardware result.

## 9. Conclusion
Write a short conclusion based on the plots and measured simulation output.
