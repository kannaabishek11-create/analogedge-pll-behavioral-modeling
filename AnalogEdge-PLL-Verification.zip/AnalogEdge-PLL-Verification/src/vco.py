"""Behavioral voltage-controlled oscillator (VCO) model."""
import numpy as np

class VCO:
    def __init__(self, free_running_frequency=850.0):
        self.free_running_frequency = float(free_running_frequency)
        self.phase = 0.0

    def step(self, control_frequency, dt, frequency_noise_std=0.0, rng=None):
        if rng is None:
            rng = np.random.default_rng()
        noise = rng.normal(0.0, frequency_noise_std) if frequency_noise_std > 0 else 0.0
        output_frequency = self.free_running_frequency + control_frequency + noise
        output_frequency = max(0.0, output_frequency)
        self.phase += 2.0 * np.pi * output_frequency * dt
        return output_frequency, self.phase
