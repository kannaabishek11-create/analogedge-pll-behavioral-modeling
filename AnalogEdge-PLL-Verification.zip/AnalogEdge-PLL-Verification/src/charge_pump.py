"""Normalized behavioral charge-pump model."""
class ChargePump:
    def __init__(self, current_scale=1.0):
        self.current_scale = float(current_scale)

    def convert(self, phase_error):
        # Normalized current; phase error is measured in radians.
        return self.current_scale * phase_error / (2.0 * 3.141592653589793)
