"""PI loop-filter model."""
class LoopFilter:
    def __init__(self, kp=1200.0, ki=20000.0):
        self.kp = float(kp)
        self.ki = float(ki)
        self.integral = 0.0

    def update(self, pump_current, dt):
        self.integral += pump_current * dt
        return self.kp * pump_current + self.ki * self.integral
