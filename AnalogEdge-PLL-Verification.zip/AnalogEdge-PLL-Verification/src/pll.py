"""Top-level behavioral PLL model."""
import numpy as np
from pfd import PFD
from charge_pump import ChargePump
from loop_filter import LoopFilter
from vco import VCO

class PLL:
    def __init__(self, reference_frequency=1000.0, free_running_frequency=850.0,
                 kp=1200.0, ki=20000.0):
        self.reference_frequency = float(reference_frequency)
        self.pfd = PFD()
        self.charge_pump = ChargePump()
        self.loop_filter = LoopFilter(kp=kp, ki=ki)
        self.vco = VCO(free_running_frequency=free_running_frequency)

    def simulate(self, duration=0.30, dt=1e-5, phase_noise_std=0.0,
                 frequency_noise_std=0.0, seed=7):
        if dt <= 0 or duration <= 0:
            raise ValueError("duration and dt must be positive")
        count = int(duration / dt)
        time = np.arange(count) * dt
        ref_phase = 2.0 * np.pi * self.reference_frequency * time
        phase_error = np.zeros(count)
        output_frequency = np.zeros(count)
        rng = np.random.default_rng(seed)

        for i in range(count):
            measured_error = self.pfd.detect(
                ref_phase[i], self.vco.phase, phase_noise_std, rng
            )
            pump_current = self.charge_pump.convert(measured_error)
            control = self.loop_filter.update(pump_current, dt)
            output_frequency[i], _ = self.vco.step(
                control, dt, frequency_noise_std, rng
            )
            phase_error[i] = (ref_phase[i] - self.vco.phase + np.pi) % (
                2.0 * np.pi
            ) - np.pi

        return {
            "time": time,
            "reference_frequency": np.full(count, self.reference_frequency),
            "output_frequency": output_frequency,
            "phase_error": phase_error,
        }

def estimate_lock_time(data, frequency_tolerance=1.0, phase_tolerance=0.10,
                       hold_samples=100):
    """First time both errors remain within tolerance for hold_samples."""
    freq_error = np.abs(data["output_frequency"] - data["reference_frequency"])
    phase_error = np.abs(data["phase_error"])
    good = (freq_error < frequency_tolerance) & (phase_error < phase_tolerance)
    if len(good) < hold_samples:
        return None
    # Require the complete remaining trace to stay locked for a short window.
    for i in range(len(good) - hold_samples):
        if np.all(good[i:i + hold_samples]):
            return float(data["time"][i])
    return None
