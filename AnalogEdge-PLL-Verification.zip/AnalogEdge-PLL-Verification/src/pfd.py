"""Behavioral phase-frequency detector (PFD) model."""
import numpy as np

class PFD:
    def detect(self, reference_phase, feedback_phase, noise_std=0.0, rng=None):
        """Return wrapped phase error in radians, in the range [-pi, pi]."""
        error = reference_phase - feedback_phase
        error = (error + np.pi) % (2.0 * np.pi) - np.pi
        if noise_std > 0:
            if rng is None:
                rng = np.random.default_rng()
            error += rng.normal(0.0, noise_std)
        return float(error)
