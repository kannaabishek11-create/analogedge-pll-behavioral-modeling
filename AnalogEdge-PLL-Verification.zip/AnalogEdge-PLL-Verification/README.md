# AnalogEdge – PLL Behavioral Modeling and Verification

## Project overview
This beginner-friendly Python project models a Phase-Locked Loop (PLL) at behavioral level. It includes a phase detector, normalized charge pump, PI loop filter, and voltage-controlled oscillator (VCO).

## Objectives
1. Model the main PLL blocks.
2. Simulate frequency acquisition and phase-error settling.
3. Estimate lock time.
4. Study sensitivity to phase-measurement noise and equivalent timing variation.
5. Save plots and simulation data.

## Project structure
```text
AnalogEdge-PLL-Verification/
├── src/
│   ├── pfd.py
│   ├── charge_pump.py
│   ├── loop_filter.py
│   ├── vco.py
│   └── pll.py
├── results/
├── docs/
├── main.py
├── requirements.txt
└── README.md
```

## Run locally
Python 3.10 or newer is recommended.

```bash
python -m pip install -r requirements.txt
python main.py
```

The program creates these files in `results/`:
- `frequency_lock.png`
- `phase_error.png`
- `jitter_sensitivity.png`
- `pll_simulation.csv`

## Default simulation settings
- Reference frequency: 1000 Hz
- Initial free-running VCO frequency: 850 Hz
- Simulation duration: 0.30 s
- Time step: 10 microseconds

## Important modeling assumptions
- This is a simplified behavioral/educational model, not a transistor-level circuit.
- The charge-pump output is normalized.
- The loop filter is represented by a proportional-integral (PI) controller.
- The VCO is modeled by integrating its instantaneous frequency into phase.
- The jitter plot reports equivalent timing variation derived from simulated phase error. It is not a complete phase-noise spectrum or silicon measurement.
- The model does not include a physical divider, transistor parasitics, supply coupling, or a detailed charge-pump mismatch model.

## Suggested next steps
1. Change the initial VCO frequency and compare lock time.
2. Sweep the loop-filter gains (`kp` and `ki`).
3. Add frequency noise and compare its effect.
4. Document observations in `docs/`.

## Author
Add your name, department, college, and roll number here.
