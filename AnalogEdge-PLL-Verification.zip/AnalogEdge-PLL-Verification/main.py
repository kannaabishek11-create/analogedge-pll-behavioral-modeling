"""Run the AnalogEdge PLL behavioral simulation and create result plots."""
from pathlib import Path
import sys
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from pll import PLL, estimate_lock_time

RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

def main():
    ref_hz = 1000.0
    dt = 1e-5
    duration = 0.30

    pll = PLL(reference_frequency=ref_hz, free_running_frequency=850.0)
    data = pll.simulate(duration=duration, dt=dt)
    lock_time = estimate_lock_time(data)

    # Plot 1: frequency settling.
    plt.figure(figsize=(9, 4.8))
    plt.plot(data["time"], data["output_frequency"], label="PLL output")
    plt.axhline(ref_hz, linestyle="--", label="Reference")
    plt.xlabel("Time (s)")
    plt.ylabel("Frequency (Hz)")
    plt.title("PLL Frequency Acquisition and Settling")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(RESULTS / "frequency_lock.png", dpi=160)
    plt.close()

    # Plot 2: phase error.
    plt.figure(figsize=(9, 4.8))
    plt.plot(data["time"], data["phase_error"])
    plt.xlabel("Time (s)")
    plt.ylabel("Phase error (rad)")
    plt.title("PLL Phase Error During Locking")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(RESULTS / "phase_error.png", dpi=160)
    plt.close()

    # Plot 3: phase-measurement-noise sensitivity.
    noise_levels = [0.0, 0.001, 0.003, 0.01, 0.03]
    jitter_ps = []
    for noise in noise_levels:
        test_pll = PLL(reference_frequency=ref_hz, free_running_frequency=850.0)
        noisy = test_pll.simulate(
            duration=duration, dt=dt, phase_noise_std=noise, seed=11
        )
        start = int(0.75 * len(noisy["time"]))
        # Convert RMS phase error to equivalent time jitter.
        rms_phase = np.std(noisy["phase_error"][start:])
        jitter_ps.append(rms_phase / (2.0 * np.pi * ref_hz) * 1e12)

    plt.figure(figsize=(9, 4.8))
    plt.plot(noise_levels, jitter_ps, marker="o")
    plt.xlabel("PFD phase-measurement noise (rad RMS)")
    plt.ylabel("Equivalent RMS timing variation (ps)")
    plt.title("PLL Jitter Sensitivity to Phase Measurement Noise")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(RESULTS / "jitter_sensitivity.png", dpi=160)
    plt.close()

    # Save a compact CSV of the main simulation.
    np.savetxt(
        RESULTS / "pll_simulation.csv",
        np.column_stack((data["time"], data["output_frequency"], data["phase_error"])),
        delimiter=",",
        header="time_s,output_frequency_hz,phase_error_rad",
        comments=""
    )

    print("Simulation completed.")
    print(f"Reference frequency: {ref_hz:.1f} Hz")
    print(f"Initial free-running VCO frequency: 850.0 Hz")
    print(f"Estimated lock time: {lock_time if lock_time is not None else 'Not detected'}")
    print("Created plots and CSV file in the results/ folder.")

if __name__ == "__main__":
    main()
